package SmartShop.Spring_Boot_SmartShop;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringBootSmartShopApplicationTests {

	@Test
	public void contextLoads() {
	}

}
