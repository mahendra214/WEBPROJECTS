/*package com.smartshop.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PriceConstraintValidator implements ConstraintValidator<PriceValidation,String> {  
  
    public boolean isValid(int s, ConstraintValidatorContext cvc) {  
          
        boolean result=s.contains("jtp");  
        return result;  
    }
}  */