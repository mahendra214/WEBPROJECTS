package com.smartshop.service;

import com.smartshop.entity.Users;

public interface UserService {
	public void saveUser(Users users);
}
