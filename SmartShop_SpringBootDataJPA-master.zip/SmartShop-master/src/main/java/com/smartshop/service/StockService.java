package com.smartshop.service;

import com.smartshop.entity.Stock;

public interface StockService {

	public void saveStock(Stock stock);
	public Stock editStock(int stockId);
	
}
