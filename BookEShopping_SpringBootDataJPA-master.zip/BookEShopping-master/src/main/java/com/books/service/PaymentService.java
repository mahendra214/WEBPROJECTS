package com.books.service;

import com.books.entity.Payment;

public interface PaymentService {
	public void savePayments(Payment payments);
}
